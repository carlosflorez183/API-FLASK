Personas=[{"name": "Juan", "age":  "32", "gender": "Masculino"},
          {"name": "Rosa", "age":  "29", "gender": "Femenino"},
          {"name": "Carlos", "age":  "19", "gender": "Masculino"}
         ]