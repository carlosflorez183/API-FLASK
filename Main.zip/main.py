from flask import Flask, jsonify
from bd.Personas import Personas
app = Flask(__name__)

@app.route('/')
def main():
  return jsonify({"message": "API FLASK"})

@app.route('/Personas', methods=["GET"])
def getPersonas():
  return jsonify({"Personas": Personas})

if __name__ == '__main__':
  app.run(debug=True, port=4000)