#Importamos la libreria json y Falsk para crear la appi y el servidor, y la carpeta donde estan las personas
from flask import Flask, jsonify
from bd.Personas import Personas
#Creamos la appi definiendo la ruta y el nombre de la appi
app = Flask(__name__)


#Definimos la ruta de la appi y la funcion que se va a ejecutar cuando se llame a la ruta
@app.route('/')
def main():
  return jsonify({"message": "API FLASK"})


#Definimos la ruta para donde se va obtener la información de las personas y creamos la funcion que se va a ejecutar cuando se llame la ruta
@app.route('/Personas', methods=["GET"])
def getPersonas():
  return jsonify({"Personas": Personas})


#Creamos una condición para que si se llama a la ruta con un metodo diferente a GET, se devuelva un mensaje de error y no inicie la appi
if __name__ == '__main__':
  app.run(debug=True, port=4000)